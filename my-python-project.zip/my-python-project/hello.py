import sys

print("Hello %s!" % sys.argv[1])
